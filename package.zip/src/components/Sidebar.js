// // Sidebar.js

// import React from 'react';

// const Sidebar = () => {
//   return (
//     <div className="sidebar">
//       <h2>Sidebar</h2>
//       <ul>
//         <li><a href="/">Home</a></li>
//         <li><a href="/dashboard">Dashboard</a></li>
//         <li><a href="/profile">Profile</a></li>
//         {/* Add more navigation links as needed */}
//       </ul>
//     </div>
//   );
// }

// export default Sidebar;
