import React, { useContext, useEffect } from "react";
import packersAndMoversLogo from "../assets/logo.jpg";
import { LoginData} from "../utils/userContext";
import { useNavigate } from "react-router-dom";
import { loginApiUrl } from "../utils/constants";

import appRouter from "./../App";

const Header = () => {
  const { setAccessToken } = useContext(LoginData);
  const navigate = useNavigate();
  let inputData = {};

  const loginApifn = async () => {
    try {
      const response = await postData(loginApiUrl, inputData);
      if (response?.is_admin === true) {
        console.log(response?.access_token);
        setAccessToken(response?.access_token);
        localStorage.setItem("accessToken", response?.access_token);
        navigate("/dashboard");
        console.log("navigating to the dashboard ")
      }
    } catch (error) {
      console.error("Error:", error);
    }
    loginApifn(inputData);
  };

  const postData = async (url = "", data = {}) => {
    const response = await fetch(url, {
      method: "POST",
      headers: {},
      body: JSON.stringify(data),
    });
    return response.json();
  };
  
  return (
    <div className=" flex border-b-2 bg-white shadow-lg rounded-lg p-4 items-center">
      <a href="/">
        <img src={packersAndMoversLogo} alt="logo" />
      </a>
      <h1 className="font-serif font-bold text-2xl text-blue-900 mx-2">
        Active Packers & Movers
      </h1>
    </div>
  );
};

export default Header;
